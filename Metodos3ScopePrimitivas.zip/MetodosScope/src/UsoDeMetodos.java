//Scope de variables primitivas
public class UsoDeMetodos 
{

	public static void main(String[] args) 
	{
		int n=3;
		System.out.println("n en el main vale "+n);//3
		incrementar(n);
		System.out.println("n en el main vale "+n);//4 MAL => 3 CORRECTO 

	}
	
	public static void incrementar(int n) 
	{
		n=n+1;
	}


}

