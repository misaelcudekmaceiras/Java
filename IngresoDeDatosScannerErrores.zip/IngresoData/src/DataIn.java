import java.util.Scanner;

public class DataIn 
{

	public static void main(String[] args) 
	{
        int numeroint=0;
        Scanner teclado=new Scanner(System.in);
        System.out.println("gentil y bien intencionado usuario ingrese un numero entero ");
        numeroint=teclado.nextInt();
        System.out.println("el numero ingresado fue "+numeroint); 

	}

}
