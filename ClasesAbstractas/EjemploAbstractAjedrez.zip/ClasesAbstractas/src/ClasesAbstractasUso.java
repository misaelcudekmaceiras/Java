
public class ClasesAbstractasUso 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}

}


abstract class Figura 
{
	//bla bla bla
	
	public abstract void mover();

	//public abstract void decirPieza();


}

class Peon extends Figura
{
	public  void mover()
	{
		
	}
}

class Alfil extends Figura
{
	public  void mover()
	{
		
	}
}
