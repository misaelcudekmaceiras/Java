
public  abstract class EjemploAbstract  
{
	public int num=0;
	
	void m1() 
	{ 
	num++;	
	}
	
	abstract void m2();

}

 class clase extends EjemploAbstract 
{
	
	void m2()
	{
		int a;
	}

}
