
public class ClaseAbstracta 
{

	public static void main(String[] args)
	{
		

	}

}


