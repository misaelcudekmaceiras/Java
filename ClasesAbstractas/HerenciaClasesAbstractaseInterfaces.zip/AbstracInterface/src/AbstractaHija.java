
public class AbstractaHija extends AbstractaPadre implements Saludadora,Bienvenido,HastaLaVista
{
	public int numAbsHija;
	
	public void mAbs1()
	{
		System.out.println("Soy mAbs1 definido en AbstractaHija"
				+ " declarado en AbstractaPadre ");
	}

	@Override
	public void Chau() 
	{
		System.out.println("chau");	
	}

	@Override
	public void hola() 
	{
		System.out.println("hola");	
	}

	@Override
	public void Saludo() 
	{
		hola();
		Chau();
	}

}
