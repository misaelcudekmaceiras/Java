
public class AbstraceInterface 
{

	public static void main(String[] args)
	{
		Clase c=new Clase();
		c.m1();
		c.mAbs1();
		c.mClase();
		c.hola();
		c.Chau();
		c.Saludo();

	}

}
