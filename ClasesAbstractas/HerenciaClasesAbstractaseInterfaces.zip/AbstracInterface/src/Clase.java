
public class Clase extends AbstractaHija
{
	public void mClase()
	{
		System.out.println("Soy mClase definido en Clase "); 
	}
}
