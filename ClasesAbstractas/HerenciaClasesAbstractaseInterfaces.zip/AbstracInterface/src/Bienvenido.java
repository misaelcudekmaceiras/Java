
public interface Bienvenido 
{
	public abstract void hola();
}
