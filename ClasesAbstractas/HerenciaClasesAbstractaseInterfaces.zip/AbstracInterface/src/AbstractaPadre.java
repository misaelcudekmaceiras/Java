
public abstract class AbstractaPadre
{
	public int num1;
	
	public void m1()
	{
		System.out.println("Soy m1 definido en AbstractaPadre "); 
	}
	
	public abstract void mAbs1(); 

}
