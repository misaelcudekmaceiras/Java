
public interface Saludadora 
{
	//int numero;
	final int valorInicial=0;
	
	public abstract void Saludo();

}
