
public interface HastaLaVista 
{	final public int x=0;//no private
	public abstract void Chau();
}
