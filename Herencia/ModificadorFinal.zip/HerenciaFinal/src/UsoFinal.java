
public class UsoFinal 
{

	public static void main(String[] args) 
	{
		MiClase o1=new MiClase();
		System.out.println("Precio con iva" +" "+ o1.CalcuPrecioConIva(30));
		System.out.println("Precio con iva" +" "+ o1.iva_gene);
		//o1.iva_gene=42;
		
		MiClaseHija o1h=new MiClaseHija();
		System.out.println("Precio con iva" +" "+ o1h.CalcuPrecioConIva(30));
		System.out.println("Precio con iva" +" "+ o1h.iva_gene);
		//o1h.iva_gene=42;
	}

}

class MiClase
{
public final  int iva_gene=21;
private final double iva_info=10.5;
public final double gravedad=-9.88;

public double CalcuPrecioConIva(double precio)
{
	return(precio+precio*iva_gene/100);
}

}

final class MiClaseHija extends MiClase
{
	MiClaseHija()
	{
		
		
	}
}

class MiClaseHijadeHija extends MiClaseHija
{
	
}

