
public class People {

	public static void main(String[] args) 
	{
	Persona p1=new Persona("misa",31313213);
	p1.mostrar();
	Alumno a1=new Alumno("misa","1/1/1986",1231231);
	a1.mostrar();
	}

}

class Persona
{
private int dni;
public String nombre;
protected int edad;

public void setDni(int dni)
{ this.dni=dni;
}

public int getDni()
{
	return(this.dni);
}

 public Persona()
{

}
 
public Persona(String nombre, int dni) 
{
	this.nombre=nombre;
	this.dni=dni;
}
public void mostrar()
					{
	System.out.println("nombre"+nombre+" "+"dni"+dni);
					}


}

class Alumno extends Persona
{
	private String alta;
	
	
	public Alumno (String nombre,String fecha,int dni)
	{
		
		super.nombre=nombre;
		//super.dni=dni;
		super.setDni(dni);
		this.alta=fecha;
		super.edad=22;
	}
	
	public void mostrar()
	{
		
		System.out.println("nombre"+nombre+" "+"dni"+super.getDni()+
			"fecha "+alta);	
	}
	
}

class Clase
{
Alumno a=new Alumno("juan","1/1/2017",123456);	
//System.out.println(a.edad);

}

