import java.util.Scanner;

public class DataIn 
{

	public static void main(String[] args) 
	{
        int numeroint=0;
        Scanner teclado=new Scanner(System.in);
        numeroint=teclado.nextInt();
        
        System.out.println("el numero ingresado fue "+numeroint); 

	}

}
