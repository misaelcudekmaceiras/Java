
public class UsoDeMetodos 
{

	public static void main(String[] args) 
	{
		bienvenida();//invocando al metodo();
		int num=5;
		duplicador(num);
		System.out.println("num vale "+num);

	}
	
	public static void bienvenida() 
	{
		System.out.println("Bienvenido al programa");
		System.out.println("Espero que estos videos sean de tu utilidad");
		System.out.println("Si te gustan compartilos con tus conocidos");
	}
	
	public static void duplicador(int n) 
	{
		n=n*2;
		System.out.println("el doble de n es "+n);
	}

}

