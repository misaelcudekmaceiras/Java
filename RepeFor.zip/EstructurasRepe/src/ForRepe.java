import java.util.Scanner;

public class ForRepe 
{

	public static void main(String[] args) 
	{
        int num=0,num2=4;
        // (condicion inicial;condicion permanencia; incremento)
       for( num=0,num2=-9;num<5;num++,num2--) 
       {
    	   System.out.println(" num vale "+num);
    	   System.out.println(" num2 vale "+num2);
       }
//? que valor tiene num aca
       //System.out.println("num vale "+num);
        System.out.println("Fin del programa vuelva prontoss");
        
        }

        
        

}
