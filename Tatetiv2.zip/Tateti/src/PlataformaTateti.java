
public class PlataformaTateti 
{

	public static void main(String[] args) 
	{
		Tateti t1=new Tateti();
		t1.generarTablero();
		t1.mostrarTablero();
		Jugador j1=new Jugador("X","Misa",t1);
		Jugador j2=new Jugador("O","Pepe",t1);
		
		boolean gan=false;
		
		while(gan==false) 
		{
			j1.jugar();
			t1.mostrarTablero();
			if(!(gan=t1.hayTateti())) 
			{
				j2.jugar();
				t1.mostrarTablero();
				gan=t1.hayTateti();
			}

		}
		
		if(gan==true)
		{
			System.out.print("Hay un ganador y es " +t1.getFichaGan());
		}

		
		

	}

}
