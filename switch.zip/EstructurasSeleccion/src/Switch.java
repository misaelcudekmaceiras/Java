import java.util.Scanner;

public class Switch 
{

	public static void main(String[] args) 
	{
        int numeroint=0;
        Scanner t=new Scanner(System.in);
        System.out.println("ingrese un numero entero ");
        numeroint=t.nextInt();

        switch(numeroint) 
        {
        default:System.out.println("opcion invalida");break;
        
        case 1:System.out.println("Lunes");break;
        case 2:System.out.println("Martes");break;
        case 3:System.out.println("Miercoles");break;
        case 4:System.out.println("Jueves");break;
        case 5:System.out.println("Viernes");break;
        case 6:System.out.println("Sabado");break;
        case 7:System.out.println("Domingo");break;
        
        }

        
        
	}

}
