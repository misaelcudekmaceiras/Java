//Scope de variables primitivas
public class UsoDeMetodos 
{

	public static void main(String[] args) 
	{
		int n=3;
		double d= 4.123;
		
		mostrarDoble(3);
		mostrarDoble(4.123);

	}
	
	public static void mostrarDoble(int num) 
	{
		System.out.println(num*2);
	}
	
	public static void mostrarDoble(double dou)
	{
		System.out.println(dou*2);
	}


}

