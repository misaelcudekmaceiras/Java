
public class UsoModifPuPri 
{

	public static void main(String[] args) 
	{
		Persona p1;
		p1=new Persona("misa","mace","1234",32);
//		p1.nombre="misa";
//		p1.apellido="mace";
//		p1.dni="1234";
//		p1.edad=32;
		
		//p1.setNombre("Misa");
		
	//	System.out.println("el nombre de p1 es "+p1.getNombre());
		
		p1.presentarse();

	}

}

class Persona
{
private String nombre;
private String apellido;
private String dni;
private int edad;

Persona()
{
	
}

Persona( String nombre, String apellido, String dni,int edad)
{
	this.nombre=nombre;
	this.apellido=apellido;
	this.dni=dni;
	this.edad=edad;
}

public void setNombre(String nom) 
{
nombre=nom;	
}

public String getNombre() 
{
	return(nombre);
}

public void presentarse() 
{
System.out.println("Me llamo "+nombre+" "+apellido+" mi dni es "+dni+" tengo "+edad);	
}


}