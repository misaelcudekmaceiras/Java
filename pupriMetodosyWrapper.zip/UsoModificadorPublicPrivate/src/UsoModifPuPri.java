
public class UsoModifPuPri 
{

	public static void main(String[] args) 
	{
		Persona p1;
		p1=new Persona("misa","mace","1234",(32*12));
		p1.presentarse();
	//	p1.envejecer();
		p1.wraEnvejecer(6);
		p1.presentarse();
	}

}

class Persona
{
private String nombre;
private String apellido;
private String dni;
private int edad;

Persona()
{
	
}

Persona( String nombre, String apellido, String dni,int edad)
{
	this.nombre=nombre;
	this.apellido=apellido;
	this.dni=dni;
	this.edad=edad;
}
//wrapper

public void wraEnvejecer(int mes) 
{
	envejecer(mes);
}

private void envejecer(int mes) 
{
edad=edad+mes;	
}

public void setNombre(String nom) 
{
nombre=nom;	
}

public String getNombre() 
{
	return(nombre);
}

public void presentarse() 
{
System.out.println("Me llamo "+nombre+" "+apellido+" mi dni es "+dni+" tengo "+edad);	
}


}