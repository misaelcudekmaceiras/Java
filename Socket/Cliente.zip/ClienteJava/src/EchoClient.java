import java.io.*;
import java.net.*;

class MyStreamSocket extends Socket {
  private Socket  socket;
  private BufferedReader input;
  private PrintWriter output;

  MyStreamSocket(InetAddress acceptorHost, int acceptorPort ) 
            throws SocketException, IOException{
    socket = new Socket(acceptorHost, acceptorPort );
    setStreams( );
  }

  MyStreamSocket(Socket socket)  throws IOException {
    this.socket = socket;
    setStreams( );
  }

  private void setStreams( ) throws IOException{
    // get an input stream for reading from the data socket
    InputStream inStream = socket.getInputStream();
    input = new BufferedReader(new InputStreamReader(inStream));
    OutputStream outStream = socket.getOutputStream();
    // create a PrinterWriter object for character-mode output
    output = new PrintWriter(new OutputStreamWriter(outStream));
  }

  public void sendMessage(String message) throws IOException {	
    output.println(message);  
    //The ensuing flush method call is necessary for the data to
    // be written to the socket data stream before the
    // socket is closed.
    output.flush();          
  } // end sendMessage

  public String receiveMessage( ) throws IOException {	
    // read a line from the data stream
    String message = input.readLine( );  
    return message;
  } //end receiveMessage

} //end class

class EchoClientHelper {

  static final String endMessage = ".";
  private MyStreamSocket mySocket;
  private InetAddress serverHost;
  private int serverPort;

  EchoClientHelper(String hostName, String portNum) 
         throws SocketException, UnknownHostException, IOException {
                 
    this.serverHost = InetAddress.getByName(hostName);
    this.serverPort = Integer.parseInt(portNum);
    //Instantiates a stream-mode socket and wait for a connection.
    this.mySocket = new MyStreamSocket(this.serverHost, this.serverPort); 
    System.out.println("Connection request made");
  } // end constructor
  
  public String getEcho( String message) throws SocketException, IOException{   
    String echo = "";  
    mySocket.sendMessage( message);
    // now receive the echo
    echo = mySocket.receiveMessage();
    return echo;
  } // end getEcho

  public void done( ) throws SocketException, IOException{
    mySocket.sendMessage(endMessage);
    mySocket.close( );
  } // end done 
} //end class

public class EchoClient {
  static final String endMessage = ".";

  public static void main(String[] args) {
    InputStreamReader is = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(is);
    String hostName = "localhost";
    String portNum = "7";
 
    try {
      System.out.println("Welcome to the Echo client."); 
      if (args.length == 2) {
        hostName = args[0];
        portNum = args[1];
      }
      else { 
        System.out.println("What is the name of the server host?");
        hostName = br.readLine();
        System.out.println("What is the port number of the server host?");
        portNum = br.readLine();
      }

      EchoClientHelper helper = new EchoClientHelper(hostName, portNum);

      boolean done = false;
      String message, echo;
      while (!done) {
        System.out.println("Enter a line to receive an echo "
                           + "from the server, or a single period to quit.");
        message = br.readLine( );
        if ((message.trim()).equals (endMessage)){
          done = true;
          helper.done( );
        }
      else {
        echo = helper.getEcho( message);
        System.out.println(echo);
      }
    } // end while
    } 
    catch (UnknownHostException e) {
      System.err.println("Don't know about host: " + hostName);
      System.exit(1);
    } 
    catch (IOException e) {
      System.err.println("Couldn't get I/O for " + "the connection to: " + hostName);
      System.exit(1);
    }
    catch (Exception ex) {
      System.out.println( "" + ex);
    } //end catch
  } //end main
} // end class