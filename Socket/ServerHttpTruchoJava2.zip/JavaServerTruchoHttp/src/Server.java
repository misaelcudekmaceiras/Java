import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server 
{
	  private Socket  socket;
	  private BufferedReader input;
	  private PrintWriter output;
	  private String message="hola como te va\n";
	
	Server()
	{
		
		try 
		{
			 ServerSocket Socketmio = new ServerSocket(80); 
			
			 while(true){
			 Socket clienteConectado= Socketmio.accept();
			 InputStream IN = clienteConectado.getInputStream();
			 OutputStream OUT = clienteConectado.getOutputStream();
			 
			 input = new BufferedReader(new InputStreamReader(IN));
			 
			 output = new PrintWriter(new OutputStreamWriter(OUT));
			 
			 message = input.readLine( ); 
			 
			 if(message.contains("GET / HTTP/1.1"))
			 {
			System.out.println("Coneccion desde IP "+ clienteConectado.getInetAddress() +
			"Puerto "+ clienteConectado.getPort() );
			output.print("<!DOCTYPE html>"+
					"<html>"+"<head>"+
				"<title>"+"Http Server Trucho"+
					"</title>"+"</head>"+"<body>"+" <h1>"+"Hola POO !!!  "+
				"su IP"+clienteConectado.getInetAddress()+"</h1>"+
				"</body>"+"</html>");
		output.flush();
			 }else
			 {
				 System.out.println("coneccion no soportada "+message); 
			 }

		 
			 
			 

			 
			 
			 
			

			 
			
			 
			 
			 clienteConectado.close();//10.2.124.18
			 
			 
		}
			 //Socketmio.close();
			 
			 
			
		}catch(Exception ex) {
		       ex.printStackTrace( );
	    }
	}
	
		
		
	}


