import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;


public class AtiendeLectura extends Atendedor implements Runnable 
{
	private String mensajeRX="_";

	AtiendeLectura(Socket s) 
	{
		super(s);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() 
	{
		 try {

			 do
			 {
				 if (input!=null) 
				 {
					 mensajeRX= input.readLine(); 
				 }
				 
				System.out.println("VOS: "+mensajeRX);	 
			 }
			 while(mensajeRX!=null &&(!mensajeRX.equalsIgnoreCase("chau")));
			 s.close();

			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Se cerro conexion");
			//e.printStackTrace();
		}
		
		 
		 }
	}


