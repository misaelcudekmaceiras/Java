import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


public class Chat 
{

	public static void main(String[] args) throws UnknownHostException, IOException 
	{
		Scanner  tecla=new Scanner(System.in);
		String tipo;
		
		System.out.println("Indique si quiere ser cliente o servidor");
		tipo=tecla.nextLine();
		if(tipo.equalsIgnoreCase("cliente"))
		{
			System.out.println("SOY CLIENTE");
			Socket sConexcionActual=new Socket(InetAddress.getByName("127.0.0.1"), 5555 );
			AtiendeEscritura hiloescritor=new AtiendeEscritura(sConexcionActual);
			AtiendeLectura hilolector=new AtiendeLectura(sConexcionActual);
			Thread tescritor =new Thread(hiloescritor);
			Thread tlector =new Thread(hilolector);
			
			tescritor.start();
			tlector.start();
			
		}
		else if (tipo.equalsIgnoreCase("servidor"))
		{
			System.out.println("SOY SERVIDOR");
			Servidor s=new Servidor();
			s.Inicio();
			s.escucharCliente();
			
			AtiendeEscritura hiloescritor=new AtiendeEscritura(s.socket);
			AtiendeLectura hilolector=new AtiendeLectura(s.socket);
			Thread tescritor =new Thread(hiloescritor);
			Thread tlector =new Thread(hilolector);
			
			tescritor.start();
			tlector.start();
		}
		
		

		
		

	}

}
