import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;


public class AtiendeEscritura extends Atendedor implements Runnable 
{
	private String mensajeTX="_";

	AtiendeEscritura(Socket s) 
	{
		super(s);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() 
	{
		 try {
			 int mesnum=5;
			 Scanner  tecla=new Scanner(System.in);
			 
			 while((!mensajeTX.equalsIgnoreCase("chau")) && output!=null )
			 {
				 mensajeTX=tecla.nextLine();
				output.println(mensajeTX);
				System.out.println("YO: "+mensajeTX);
				output.flush();	
			 }
			 s.close();

			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

}
