import java.io.*;
import java.net.*;

class MyStreamSocket extends Socket {
  private Socket  socket;
  private BufferedReader input;
  private PrintWriter output;

  MyStreamSocket(InetAddress acceptorHost, int acceptorPort ) 
                throws SocketException, IOException{
      socket = new Socket(acceptorHost, acceptorPort );
      setStreams( );
  }

  MyStreamSocket(Socket socket)  throws IOException {
    this.socket = socket;
    setStreams( );
  }

  private void setStreams( ) throws IOException{
    // get an input stream for reading from the data socket
    InputStream inStream = socket.getInputStream();
    input = new BufferedReader(new InputStreamReader(inStream));
    OutputStream outStream = socket.getOutputStream();
    // create a PrinterWriter object for character-mode output
    output = new PrintWriter(new OutputStreamWriter(outStream));
  }

  public void sendMessage(String message) throws IOException {	
    output.println(message);   
    //The ensuing flush method call is necessary for the data to
    // be written to the socket data stream before the
    // socket is closed.
    output.flush();               
  } // end sendMessage

  public String receiveMessage( ) throws IOException {	
    // read a line from the data stream
    String message = input.readLine( );  
    return message;
  } //end receiveMessage
} //end class


public class EchoServer {
  static final String endMessage = ".";

  public static void main(String[] args) {
    int serverPort = 7;   // default port
    String message;

    if (args.length == 1 )
      serverPort = Integer.parseInt(args[0]);     

    try {
      // instantiates a stream socket for accepting connections
      ServerSocket myConnectionSocket = new ServerSocket(serverPort); 
      System.out.println("Echo server ready.");  
      while (true) {  // forever loop
        // wait to accept a connection 
        System.out.println("Waiting for a connection.");
        MyStreamSocket myDataSocket = new MyStreamSocket (myConnectionSocket.accept( ));
        System.out.println("connection accepted");

        boolean done = false;
        while (!done) {
          message = myDataSocket.receiveMessage( );
          System.out.println("message received: "+ message);
          if ((message.trim()).equals (endMessage)){
            //Session over; close the data socket.
            System.out.println("Session over.");
            myDataSocket.close( );
            done = true;
          } 
          else {
            // Now send the echo to the requestor
            myDataSocket.sendMessage(message);
          } 
        } //end while !done
      } //end while forever
    } // end try
    catch (Exception ex) {
       ex.printStackTrace( );
    }
  } //end main
} // end class