
public class JavaServer {

	public static void main(String[] args) 
	{
		Server s=new Server();

	}

}
