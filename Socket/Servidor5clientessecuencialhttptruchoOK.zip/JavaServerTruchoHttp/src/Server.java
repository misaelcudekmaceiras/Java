import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

public class Server 
{
	  private Socket  socket;
	  private BufferedReader input;
	  private PrintWriter output;
	  private String message;
	  private String textoTX;
	  private FileInputStream flujo_a_mi_Archivo;
	
	Server()
	{
		int numbytes=0;
		try 
		{
			flujo_a_mi_Archivo = new FileInputStream("index.html");//abro
			while(flujo_a_mi_Archivo.read()!=-1)
			{
				numbytes++;
			}
			flujo_a_mi_Archivo.close();
			
			byte buff[]= new byte[numbytes];
			flujo_a_mi_Archivo = new FileInputStream("index.html");//abro
			flujo_a_mi_Archivo.read(buff);
			flujo_a_mi_Archivo.close();
			textoTX=new String("HTTP 200 OK\n");
			textoTX=textoTX.concat(new String(buff));
			ServerSocket Socketmio = new ServerSocket(5555); 
			 for(int cant=5;cant>0;cant--)
			 {
			 Socket clienteConectado= Socketmio.accept();
			 InputStream IN = clienteConectado.getInputStream();
			 OutputStream OUT = clienteConectado.getOutputStream();			 
			 input = new BufferedReader(new InputStreamReader(IN));
			 output = new PrintWriter(new OutputStreamWriter(OUT));
		
			 message = input.readLine( ); 
			 
			 output.println(textoTX); 
			 output.flush();    
			 System.out.println("enviado: "+textoTX+"a cliente "+ clienteConectado.getInetAddress());
			 System.out.println("recibido "+ message+"desde" + clienteConectado.getInetAddress() +
					 "desde el puerto "+ clienteConectado.getPort());
			 
			 clienteConectado.close();
			 }
			 Socketmio.close();
			 
		}catch(Exception ex) {
		       ex.printStackTrace( );
	    }
	}
	
		
		
	}


