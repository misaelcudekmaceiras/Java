import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server 
{
	  private Socket  socket;
	  private BufferedReader input;
	  private PrintWriter output;
	  private String message;
	
	Server()
	{
		
		try 
		{
			 ServerSocket Socketmio = new ServerSocket(2222); 
			 Socket clienteConectado= Socketmio.accept();
			 InputStream IN = clienteConectado.getInputStream();
			 OutputStream OUT = clienteConectado.getOutputStream();
			 
			 input = new BufferedReader(new InputStreamReader(IN));
			 
			 output = new PrintWriter(new OutputStreamWriter(OUT));
			 
			 message = input.readLine( ); 
			 
			 
			 
			 System.out.println("recibido "+ message 
					 +"desde" + clienteConectado.getInetAddress() +
					 "desde el puerto "+ clienteConectado.getPort()
					 
					 );
			 
			 output.println("soy el server\r\n"); 
			 
			 output.flush();         
			 

			 
			 
			 clienteConectado.close();
			 
			 Socketmio.close();
			 
			 
			
		}catch(Exception ex) {
		       ex.printStackTrace( );
	    }
	}
	
		
		
	}


