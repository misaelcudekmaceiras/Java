import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor 
{
	  public Socket clienteConectado=null;
	  public Socket socket=null;
	  private static  ServerSocket Socketmio=null;
	  private BufferedReader input=null;
	  private PrintWriter output=null;
	  private String message="";

	  
	  Servidor(Socket datoCliente)
	  {
		  clienteConectado=datoCliente;
	  }
	  Servidor()
	  {

	  }

	  public void escucharCliente()
	  {
		  try {
			socket=Socketmio.accept();
			 System.out.println("Cliente conectado :"+" desde IP" + socket.getInetAddress() +
					 " desde el puerto "+ socket.getPort()
					 );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	  
	public   void dispose() 
	  {
		  try 
		  {  
			  Socketmio.close();
		  } 
		  catch (IOException e) 
		  {
			e.printStackTrace();
		  }
	  }
	  

	  public static void Inicio()
	  {
			try 
			{
				  Socketmio = new ServerSocket(5555);
			}catch(Exception ex) 
			{
			     ex.printStackTrace( );
		    }
	  }


		
			
		


}

