import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;


public class AtiendeClientes implements Runnable 
{
	private Socket c;
	private InputStream IN;
	private OutputStream OUT;
	private BufferedReader input;
	private PrintWriter output;
	public static int cantHilos=0;
	
	public AtiendeClientes(Socket cliente)
	{
		cantHilos++;
	c=cliente;
	try {
		IN = c.getInputStream();
		OUT = c.getOutputStream();
	}
	catch (IOException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	 
	input = new BufferedReader(new InputStreamReader(IN));
	output = new PrintWriter(new OutputStreamWriter(OUT));
	}
	
	
	 public void run()
	 {
		 for(int i=0;i<5;i++)
		 {
			 output.println("Hola Cliente"); 
			 output.flush();
			 try 
			 {
				Thread.sleep(1000);
			} catch (InterruptedException e) 
			 {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 
		 
		 try 
		 {
			c.close();
			//cantHilos--;
		} 
		 catch (IOException e) 
		 {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cantHilos--;	
		
		 
	 }
	 

	
	
}
