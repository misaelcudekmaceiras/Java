import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

public class Server 
{	  
	  private Thread t;
	  private AtiendeClientes at;
	  private Socket  socket;
	  private BufferedReader input;
	  private PrintWriter output;
	  private String message;
	  private String texto;
	  private int cant = 10;
	  private int maxCantidadClientesConectados=0;
	Server()
	{
		
		try 
		{
			 ServerSocket Socketmio = new ServerSocket(80);
			 
			 while(true)
			 {
				 if(AtiendeClientes.cantHilos<5)
				 {
					 Socket clienteConectado= Socketmio.accept();
					 //cant--;
					 at=new AtiendeClientes(clienteConectado);
					 t=new Thread(at);
					 t.start();
					 
					 
					 
					 System.out.println("recibido "+ message 
							 +"desde" + clienteConectado.getInetAddress() +
							 "desde el puerto "+ clienteConectado.getPort()
							 );
					 
				 }else
				 {
					 //maxima cantidad de clientes conectados.
					 System.out.println("Maxima cantidad de clientes");
				 }
			
			 
			 
		}
			 
			// Socketmio.close();
			 
			 
			
		}catch(Exception ex) {
		       ex.printStackTrace( );
	    }
	}
	
		
		
	}


