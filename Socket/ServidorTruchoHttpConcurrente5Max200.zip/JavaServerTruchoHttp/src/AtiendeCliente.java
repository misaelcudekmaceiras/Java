import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class AtiendeCliente implements Runnable
{
	private Socket clienteConectado;
	private BufferedReader input;
	private PrintWriter output;
	private InputStream IN;
	private OutputStream OUT;
	private String textoRX;
	private String textoTX;
	public static int cantCli=0;
	  
	public AtiendeCliente(Socket cliente,String textoTX) 
	{
		cantCli++;
		System.out.println("Hay "+cantCli+" Clientes conectados");
		clienteConectado=cliente;
		this.textoTX=textoTX;
		try 
		{
			IN = clienteConectado.getInputStream();
			OUT = clienteConectado.getOutputStream();			 
			input = new BufferedReader(new InputStreamReader(IN));
			output = new PrintWriter(new OutputStreamWriter(OUT));	
		}
		catch(Exception e) 
		{
			System.out.println("Error IO");
		}	
	}
	
	public void run() 
	{
		//el manejo del cliente
		try 
		{ 
		textoRX = input.readLine( );  
		 output.println(textoTX); 
		 output.flush();    
		 //System.out.println("enviado: "+textoTX+"a cliente "+ clienteConectado.getInetAddress());
		 System.out.println("recibido "+ textoRX+"desde" + clienteConectado.getInetAddress() +
				 "desde el puerto "+ clienteConectado.getPort());
		 try {
				Thread.sleep(1000);
			 } catch (InterruptedException e) 
				{
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
		 clienteConectado.close();
		 cantCli--;
		 System.out.println("Se desconecto un cliente");
		}catch(Exception e) 
		{
			System.out.println("Error comu");
		}
		
		
		}
	
}
