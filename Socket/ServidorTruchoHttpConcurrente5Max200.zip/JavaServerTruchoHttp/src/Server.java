import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

public class Server 
{
	  private Socket  socket;
	  private BufferedReader input;
	  private PrintWriter output;
	  private String message;
	  private String textoTX;
	  private FileInputStream flujo_a_mi_Archivo;
	  private int ClientesTotal=200;
	  private AtiendeCliente clientes[]=new AtiendeCliente[5];
	
	Server()
	{
		int numbytes=0;
		try 
		{
			flujo_a_mi_Archivo = new FileInputStream("index.html");//abro
			while(flujo_a_mi_Archivo.read()!=-1)
			{
				numbytes++;
			}
			flujo_a_mi_Archivo.close();
			
			byte buff[]= new byte[numbytes];
			flujo_a_mi_Archivo = new FileInputStream("index.html");//abro
			flujo_a_mi_Archivo.read(buff);
			flujo_a_mi_Archivo.close();
			
			textoTX=new String("HTTP 200 OK\n");
			textoTX=textoTX.concat(new String(buff));
			ServerSocket Socketmio = new ServerSocket(5555); 
			
			while(ClientesTotal>0)
			{
				if(AtiendeCliente.cantCli<5)
				{
					 Socket clienteConectado= Socketmio.accept();
					 
					 AtiendeCliente a=new AtiendeCliente(clienteConectado,textoTX);
					//AtiendeCliente[i]=new AtiendeCliente( ...
					 Thread t=new Thread(a);
					 t.start();
					 ClientesTotal--;
				}
			}
			 Socketmio.close();
			 
		}catch(Exception ex) {
		       ex.printStackTrace( );
	    }
	}
	
		
		
	}


