
public class JavaCliente 
{

	public static void main(String[] args) 
	{
		Cliente c=new Cliente();
	}

}
