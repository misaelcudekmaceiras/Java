
public class CreamosClases 
{

	public static void main(String[] args) 
	{
	//<Nombre Clase> <nombre del objeto>;
		Pelota p1;//p1 es una referencia a un objeto de la clase Pelota
		p1=new Pelota("tenis",0.2,50,"esfera","hebrasdefibra");
		
		p1.getInfo();
		
		p1.geometria="ovalo";
		
		p1.getInfo();
		
		System.out.println("la geometria es "+p1.geometria);

	}

}

class Pelota
{
public String deporte;
public double peso;
public double presion;
public String geometria;
public String superficie;

Pelota(String dep,double peso,double pre,String geo,String supe)
{
	deporte=dep;
	this.peso=peso;
	presion=pre;
	geometria=geo;
	superficie=supe;
}

public void getInfo() 
{
	System.out.println("Soy pelota de "+deporte+" tengo una presion de "+presion +" psi");
}

public void picar() 
{
	
}

public void inflarse(double presion) 
{
	
}

public void desinflarse(double presion) 
{
	
}

}
