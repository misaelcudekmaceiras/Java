import java.util.Scanner;

public class WhileMientras 
{

	public static void main(String[] args) 
	{
        int numeroint=0;
        Scanner t=new Scanner(System.in);
       


        do
        {	//true
        	System.out.println("ingrese un numero entero ");
            numeroint=t.nextInt();	
        }while(numeroint!=0);
        
        
        System.out.println("Fin del programa vuelva prontoss");
        
        }

        
        

}
