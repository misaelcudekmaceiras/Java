
public class UsamosVariables 
{

	public static void main(String[] args) 
	{
		//<tipo> <nombre>=0;
        int num1=77;//32bits, enteros signo
        char sexo='f';
        String  contrasena = "zaERlk9?_Q";
        double peso=  77.55;
        
        System.out.println(num1);
        System.out.println(sexo);
        System.out.println(contrasena);
        System.out.println(peso);

	}

}
