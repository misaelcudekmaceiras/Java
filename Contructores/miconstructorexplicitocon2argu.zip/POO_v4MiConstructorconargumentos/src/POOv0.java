
public class POOv0 
{
	public static void main(String[] args) 
	{
	Persona p1=null;//p1 es una variable que va a guardar la direcion de memoria donde esta el objeto
	p1 = new Persona("misael",34);//instanciando un objeto de la clase Persona con el contructor Persona()
	p1.presentarDatos();

	}
}

class Persona
{
	public String nombre;
	public int edad;
	//Los atributos y metodos de una clase , son visibles entre si
	//cualquier atributo declarado dentro de una clase
	//es visibile por cualquier metodo de ESA clase
	public Persona(String n,int e) 
	{
		nombre=n;
		edad=e;
	}// Hice explicito el contructor por default (implicito) de java
	
	public void presentarDatos() 
	{
		System.out.println("Me llamo :"+nombre);
	}
}
/*
 * 
 * 
 * */
 