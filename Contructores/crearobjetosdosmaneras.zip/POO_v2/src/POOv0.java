
public class POOv0 
{
	public static void main(String[] args) 
	{
	Persona p1=null;//p1 es una variable que va a guardar la direcion de memoria donde esta el objeto
	p1 = new Persona();//instanciando un objeto de la clase Persona con el contructor Persona()
	p1.nombre="misa";
	p1.presentarDatos();
	
	
	Persona p2= new Persona();
	p2.nombre="saelmi";
	p2.presentarDatos();
	
	}
}

class Persona
{
	public String nombre;
	
	public void presentarDatos() 
	{
		System.out.println("Me llamo :"+nombre);
	}
}
//TODAS LAS CLASES DE JAVA TIENEN UN CONSTRUCTOR POR DEFECTO
//SE LLAMA CONSTRUCTOR IMPLICITO
//IMPLICITO: Algo que no hace falta aclarar
/*???Donde esta el constructor Persona() definido ?
 * 
 * 
 * */
 