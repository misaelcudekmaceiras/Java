import java.util.Scanner;

public class ElIfelse 
{

	public static void main(String[] args) 
	{
        int numeroint=0;
        Scanner t=new Scanner(System.in);
        System.out.println("ingrese un numero entero ");
        numeroint=t.nextInt();
        
        if(numeroint>0) 
        {	//true
        	System.out.println("el numero ingresado fue mayor a cero");
        }
         else if(numeroint<0)
        {	//true del else if
        	System.out.println("el numero ingresado fue menor a cero");	
        }else 
        {
        	System.out.println("el numero ingresado fue  cero");
        }
        
        
	}

}
