
public class UsoDeMetodos 
{

	public static void main(String[] args) 
	{
		System.out.println("el resultado de la suma es "+suma(4,3));
		System.out.println("el valor de pi es  "+darValorPi());

	}
	
	public static double darValorPi() 
	{
		return(3.14);
	}
	
	public static int suma(int a,int b)
	{
		return(a+b);
	}
	
	public static void bienvenida() 
	{
		System.out.println("Bienvenido al programa");
		System.out.println("Espero que estos videos sean de tu utilidad");
		System.out.println("Si te gustan compartilos con tus conocidos");
	}
	
	public static void duplicador(int n) 
	{
		n=n*2;
		System.out.println("el doble de n es "+n);
	}

}

